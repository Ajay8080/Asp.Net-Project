﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserProductManager.Data;
using UserProductManager.Models;

namespace UserProductManager.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProductController(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _context.Products
                .FromSqlRaw("SELECT Id, Name, Price, Description, ImagePath FROM Products")
                .ToListAsync();

            return View(products);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(Product product, IFormFile imageFile)
        {
            string imagePath = null;

            if (imageFile != null && imageFile.Length > 0)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "images");
                Directory.CreateDirectory(uploadsFolder);
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + imageFile.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }

                imagePath = "/images/" + uniqueFileName;
            }

            string query = "INSERT INTO Products (Name, Price, Description, ImagePath) VALUES (@p0, @p1, @p2, @p3)";
            await _context.Database.ExecuteSqlRawAsync(query, product.Name, product.Price, product.Description, imagePath);

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var product = await _context.Products
                .FromSqlRaw("SELECT Id, Name, Price, Description, ImagePath FROM Products WHERE Id = {0}", id)
                .FirstOrDefaultAsync();

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product product, IFormFile imageFile)
        {
            string imagePath = product.ImagePath;

            if (imageFile != null && imageFile.Length > 0)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "images");
                Directory.CreateDirectory(uploadsFolder);
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + imageFile.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }

                imagePath = "/images/" + uniqueFileName;
            }

            string query = "UPDATE Products SET Name = @p0, Price = @p1, Description = @p2, ImagePath = @p3 WHERE Id = @p4";
            await _context.Database.ExecuteSqlRawAsync(query, product.Name, product.Price, product.Description, imagePath, product.Id);

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Products
                .FromSqlRaw("SELECT Id, Name, Price, Description, ImagePath FROM Products WHERE Id = {0}", id)
                .FirstOrDefaultAsync();

            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _context.Database.ExecuteSqlRawAsync("DELETE FROM Products WHERE Id = {0}", id);
            return RedirectToAction(nameof(Index));
        }
    }
}
